import none from "./none";

export default function(series) {
  return none(series).reverse();
}
